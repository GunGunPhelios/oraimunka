#burgonya 450ft/kg
#répa ára 300ft/kg

b= 450
r= 300
valasz=input("Milyen zöldséget szeretne?(burgonya/répa):").lower()
mennyiseg= float(input("Mennyit szeretne vásárolni?: ").strip())
vegösszeg=0
if valasz== "burgonya" :
    vegösszeg=b*mennyiseg
    print(f"Választott zöldség: Burgonya, mennyiség: {mennyiseg} kg.")
elif valasz == "répa":
    vegösszeg=r *mennyiseg
    print(f"A választott zöldség: Répa, mennyiség {mennyiseg} kg.")
else:
    print("Ismeretlen zöldségtípus!")
    exit()

print(f"Fizetendő végösszeg: {vegösszeg} ft.")