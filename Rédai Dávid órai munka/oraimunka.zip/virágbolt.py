rózsa= 300
tulipán= 200

virag= input("Milyen virágot kér? ").lower()
mennyiség= int(input("Hány szálat kér?"))

vegosszeg=0
if virag== "rózsa":
    vegosszeg= rózsa*mennyiség
    print(f"Választott virágod: Rózsa, mennyiség: {mennyiség} szál.")
elif virag== "tulipán" or "tulipan" or "tulip":
    vegosszeg= tulipán*mennyiség
    print(f"Választott virágod: Tulipán, mennyiség: {mennyiség} szál.")
else:
    print("Nem ismerem ezt a virágot.")
    exit()

print(f"A végső összeged: {vegosszeg} ft. ")