kutya= 1200
cica= 1500

táp= input("Milyen állateledelt szeretne venni? ").lower()
mennyiség= int(input("Hány kilót kér? "))

vegosszeg=0
if táp== "kutya":
    vegosszeg= mennyiség*kutya
    print(f"A választott eledeled: kutya: mennyiség {mennyiség} kg.")
elif táp == "macska" or "cica":
    vegosszeg= cica*mennyiség
    print (f"A választott eledeled: cica: mennyiség {mennyiség} kg.")
else:
    print("Nem ismerek ilyen háziállatot!")
    exit()
print(f"Fizetendő végösszeged: {vegosszeg} Ft.")