felnott= 2000
gyerek= 1500

film= input("Milyen jegyet szeretne venni? ").lower()
Mennyiség= int(input("Hány jegyet kér? "))

vegosszeg=0
if film == "felnott": 
    vegosszeg= Mennyiség* felnott
    print(f"Válaszott jegyed: felnőtt, mennyisége {Mennyiség} db.")
elif film== "gyerek":
    vegosszeg= Mennyiség*gyerek
    print(f"Válaszott jegyed: gyerek, mennyisége {Mennyiség} db.")
else: 
    print("Nem ismerek ilyet!")
    exit()
print(f"Fizetendő összeged: {vegosszeg} ft.")