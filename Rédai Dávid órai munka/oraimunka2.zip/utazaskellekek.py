import random
kellekek=[]

while len(kellekek) <7:
    cucc= input(f"Kérem adja meg az utazáshoz szükséges kelléket {len(kellekek) +1 }. kellék.) ")
    kellekek.append(cucc)
    print(f"{len(kellekek)}. holmi {cucc} hozzáadva a listához.")

print("\nA teljes lista ami a kellékeket tartalmazza:")
for index,cucc in enumerate(kellekek,1):
    print(f" {index}. {cucc}")

fontoskellek=random.choice(kellekek)
print(f"\nA fontos kellék: {fontoskellek}")
