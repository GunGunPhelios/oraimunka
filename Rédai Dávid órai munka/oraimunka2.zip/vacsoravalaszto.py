import random


ételek = []


while len(ételek) < 6:
    fogás = input(f"Kérem adja meg a fogás nevét ({len(ételek) + 1}. étel): ")
    ételek.append(fogás)
    print(f"{len(ételek)}. étel: {fogás} hozzáadva a listához.")


print("\nA teljes lista a következő fogásokat tartalmazza:")
for index, fogás in enumerate(ételek, 1):
    print(f"{index}. {fogás}")


aházajánlata = random.choice(ételek)
print(f"\nA ház ajánlata: {aházajánlata}")
